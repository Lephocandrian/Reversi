/**
 * @Ryan Leffler
 * This class represents the board, peices, and rules for the game "Reversi".
 **/
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.Array;
import java.util.*;
public class Reversi extends JFrame{
  /** This controls how the JButtons are displayed in the JFrame; the length and width of the board. **/
  private JPanel board;
  /** This holds the JButtons which comprise the board.**/
  private JButton[] grid;
  /** This is used by the main method to remember if the dimensions entered by the user are valid. **/
  public static boolean validD = true;
  /** This remembers whose turn it is currently. **/
  public static boolean p1 = true;
  /** This remembers the board height. **/
  private int a;
  /** This remembers the board width. **/
  private int b;
  /** This remembers player1's color. **/
  private Color p1Color = Color.blue;
  /** This remembers player2's color. **/
  private Color p2Color = Color.yellow;
  /** This remembers the place in the board array of the JButton currently being checked for move-validity. **/
  private int potentiateNum = 0;
  /** This remembers whether a direction on the board is valid for peice-flipping or not.**/
  private static boolean suitableVector = false;
  /** This remembers if the turn switches or not on a click. **/
  private static boolean tickTurn = false;
  
  /**
   * Constructor used if the user does not enter input.
   **/
  public Reversi(){
    this.a = 8;
    this.b = 8;
    Reversi.ColorChooser colorChooser = this.new ColorChooser();
  }
  
  /**
   * Constructor used if the user enters a single dimensional input.
   * @int a
   **/
  public Reversi(int a){
    this.a = a;
    this.b = a;
    Reversi.ColorChooser colorChooser = this.new ColorChooser(); 
  }
  
  /**
   * Constructor used if the user enters two dimensional inputs.
   * @int a
   * @int b
   **/
  public Reversi(int a, int b){
    this.a = a;
    this.b = b;
    Reversi.ColorChooser colorChooser = this.new ColorChooser();
  }
  
  public class ColorChooser extends JFrame{
    /**
     * Constructor for the color choosing JFrame.
     **/
    public ColorChooser(){
      this.setTitle("Player 1, choose your color.");
      this.setSize(400, 80);
      /** This holds the JButtons of the ColorChooser JFrame. **/
      JButton[] colorOptions = new JButton[8];
      /** This controls how the JButtons are displayed in the ColorChooser JFrame. **/
      JPanel choices = new JPanel();
      /** Adds a JButton with an actionListener to each spot in the colorOptions array. **/
      for(int i = 0; i < 8; i++){
        colorOptions[i] = new JButton();
        choices.add(colorOptions[i]);
        colorOptions[i].addActionListener(new ButtonListener());
      }
      colorOptions[0].setBackground(Color.red);
      colorOptions[1].setBackground(Color.orange);
      colorOptions[2].setBackground(Color.yellow);
      colorOptions[3].setBackground(Color.green);
      colorOptions[4].setBackground(Color.cyan);
      colorOptions[5].setBackground(Color.blue);
      colorOptions[6].setBackground(Color.magenta);
      colorOptions[7].setBackground(Color.pink);
      this.setVisible(true);
      /** This allows the JFrame display the components created in this method. **/
      Container c = this.getContentPane();
      c.add(choices, "Center");
    }
    
      public class ButtonListener implements ActionListener {
        /**
         * Overrides the actionPerformed method of the action listener to allow players to select their color from a
         * selection of 8 playable colors.
         * @ActionEvent a
         **/
        public void actionPerformed(ActionEvent a){
          /** This remebers the JButton that was clicked. **/
          JButton b = (JButton) a.getSource();
          /** This remember if the color choosing proccess is completed or not. **/
          boolean done = false;
          if(p1){
            p1 = false;
            Reversi.this.p1Color = b.getBackground();
            b.setText("p1");
            ColorChooser.this.setTitle("Player 2, choose your color.");
          }
          else if((p1 == false)&& (b.getBackground().equals(Reversi.this.p1Color) == false)){
            p1 = true;
            Reversi.this.p2Color = b.getBackground();
            b.setText("p2");
            done = true;
          }
          if(done){
            ColorChooser.this.dispatchEvent(new WindowEvent(ColorChooser.this, WindowEvent.WINDOW_CLOSING));
            Reversi.this.setup(Reversi.this.a, Reversi.this.b);
          }
        }
      }
    
  }
  
  
  /**
   * Initializes the game board, including its size and placing down the four starting peices.
   * @int a
   * @int b
   **/
  public void setup(int a, int b){
    this.setSize(700, 700);
    board = new JPanel(new GridLayout(a, b));
    grid = new JButton[(a * b)];
    for(int i = 0; i < (a * b); i++){
      grid[i] = new JButton();
      grid[i].setBackground(Color.gray);
      grid[i].addActionListener(new ButtonListener());
      board.add(grid[i]);
    }
    grid[coor2Num((this.b/2) - 1,(this.a/2) - 1)].setBackground(p2Color);
    grid[coor2Num((this.b/2),(this.a/2) - 1)].setBackground(p1Color);
    grid[coor2Num((this.b/2),(this.a/2))].setBackground(p2Color);
    grid[coor2Num((this.b/2) - 1,(this.a/2))].setBackground(p1Color);
    /** This allows the JFrame display the components created in this method. **/
    Container c = this.getContentPane();
    c.add(board, "Center");
    this.setVisible(true);
  }
  
  /**
   * Converts an array of (x,y) coordinates to the number of the coressponding JButton in the grid array.
   * @int x
   * @int y
   **/
  public int coor2Num(int x, int y){
    return (this.b * y) + x;
  }
  
  /**
   * Converts the number of a JButton in the grid array to the (x,y) coordinates coressponding to the JButton's spot on
   * the JPanel.
   * @int num
   **/
  public int[] num2Coor(int num){
    int[] coor = new int[2];
    coor[0] = (num - (num / this.b) * b);
    coor[1] = num / this.b;
    return coor;
  }
  
  public class ButtonListener implements ActionListener {
  /**
   * Overrides the actionPerformed method of the action listener to execute the methods to check if a players turn
   * must be skipped, check if the game has been won, and enforce player moves/turns.
   * @ActionEvent a
   **/
    public void actionPerformed(ActionEvent a){
      /** This remebers the JButton that was clicked. **/
      JButton b = (JButton) a.getSource();
      if(p1){
        Reversi.this.isLegal(Reversi.this.immediateNemisis(b));
        if(tickTurn){
          b.setBackground(Reversi.this.p1Color);
          p1 = false;
          System.out.println("Player 2, it's your turn");
          Reversi.this.hasLegalMove();
        }
      }
      else{
        Reversi.this.isLegal(Reversi.this.immediateNemisis(b));
        if(tickTurn){
          b.setBackground(Reversi.this.p2Color);
          p1 = true;
          System.out.println("Player 1, it's your turn");
          Reversi.this.hasLegalMove();
        }
      }
      Reversi.this.gameOver();
    }
  }
  
  /**
   * Checks if a JButton's 8 immediatly surrounding JButtons are the color of the current players opponent. Returns an
   * array of (x,y) displacements of immediatly surrounding JButtons that are the color of the current players opponent.
   * @JButton a
   **/
  public int[][] immediateNemisis(JButton a){
    this.potentiateNum = 0;
    int[][] potentiateNem = new int[9][2];
    /** Finds the number of the clicked button in the grid array. **/
    for(int i = 0; i < (this.a*this.b); i++){
      if(a == this.grid[i])
        this.potentiateNum = i;
    }
    /** This remembers the color of the player who is currently the opponent. **/
    Color nemisisColor = p2Color;
    /** The following six variables are index modifiers for checking edge spaces**/
    int l = 0;
    int j = 1;
    int k = 1;
    int j1 = -2;
    int k1 = -2;
    if(this.num2Coor(this.potentiateNum)[0] == l)
      j = 0;
    if(this.num2Coor(this.potentiateNum)[0] == this.b - 1)
      j1 = -1;
    if(this.num2Coor(this.potentiateNum)[1] == l)
      k = 0;
    if(this.num2Coor(this.potentiateNum)[1] == this.a - 1)
      k1 = -1;
    if(p1 == true)
      nemisisColor = p2Color;
    if(p1 == false)
      nemisisColor = p1Color;
    if(grid[this.potentiateNum].getBackground().equals(Color.gray)){
      for(int b = j; b > j1; b = b - 1){
        for(int c = k; c > k1; c = c - 1){
          if(grid[this.coor2Num((this.num2Coor(this.potentiateNum)[0] - b), (this.num2Coor(this.potentiateNum)[1] - c))].getBackground().equals(nemisisColor)){
            potentiateNem[l][0] = -b;
            potentiateNem[l][1] = -c;
            l = l + 1;
          }
        }
      }
    }
    return potentiateNem;
  }
  /** This receives result of immediateNemisis and calls vector checker. **/
  public void isLegal(int[][] a){
    this.vectorChecker(this.num2Coor(this.potentiateNum)[0], this.num2Coor(this.potentiateNum)[1], a);
  }
  
  /**
   * Receives the result of immediateNemisis and if any peice-filled directions can legally be turned to the current 
   * players color, turns them. If no suitable directions (vectors) are found, inhibits the current players turn from
   * ending (as they have not clicked on a legal move) by keeping the boolean "tickTurn" false.
   * @int x
   * @int y
   * @int[][]z
   * @ArrayIndexOutOfBoundsException f
   **/
  public void vectorChecker(int x, int y, int[][] z){
    /** This remembers the current players color. **/
    Color playerColor = p1Color;
    tickTurn = false;
    /** This remembers if a vector is unsuitable to be flipped. **/
    boolean suitableVector1;
    if(p1 == false)
      playerColor = p2Color;
    /** Checks in what directions there is an opponents color.  **/
    for(int i = 0; i < 9; i++){
      if((z[i][0] != 0) || (z[i][1] != 0)){
        suitableVector = false;
        suitableVector1 = true;
        try{
          int suitable = 0;
          int j = 2; 
          /** 
           * Checks the directions in which opponent colors are found to see if they are suitable to be flipped to the
           * current player's color.
           **/
          while ((suitableVector == false) && (suitableVector1)){
            if(grid[this.coor2Num((x + (j * z[i][0])), (y + (j * z[i][1])))].getBackground().equals(playerColor)){
              suitableVector = true;
              tickTurn = true;
            }
            if(grid[this.coor2Num((x + (j * z[i][0])), (y + (j * z[i][1])))].getBackground().equals(Color.gray)){
            suitableVector = true;
            suitableVector1 = false;
            }
            if(((x + (j * z[i][0])) > (this.b - 1)) || ((x + (j * z[i][0])) < 0) || ((y + (j * z[i][1])) > (this.a - 1)) || ((y + (j * z[i][1])) < 0)){
            suitableVector = true;
            suitableVector1 = false;
            }
            else{
              j = j + 1;
            }
          }
        }
        catch(ArrayIndexOutOfBoundsException f){}
        if((suitableVector) && (suitableVector1)){
          int k = 1;
          /** Flips the peices along any vector found suitable for flipping to current player's color. **/
          while((grid[this.coor2Num((x + (k * z[i][0])), (y + (k * z[i][1])))].getBackground().equals(playerColor) == false) && 
                (grid[this.coor2Num((x + (k * z[i][0])), (y + (k * z[i][1])))].getBackground().equals(Color.gray) == false)){
            grid[this.coor2Num((x + (k * z[i][0])), (y + (k * z[i][1])))].setBackground(playerColor);
            k = k + 1;
          }
        }
      }
    }
  }
  
  /**
   * Checks to see if there are any legal moves left for the current player.
   **/
  public boolean movesLeft(){
    /** Remembers if the current player has moves left or not. **/
    boolean result = false;
    /** Remembers the current position of every game-peice. **/
    Color[] saveBoard = new Color[(this.a * this.b)];
    /** Creates a copy of the current game state. **/
    for(int i = 0; i < (this.a * this.b); i++){
      saveBoard[i] = grid[i].getBackground();
    }
    /** Checks if the current player has moves remaining. **/
    for(int i = 0; i < (this.a * this.b); i++){
      this.isLegal(this.immediateNemisis(grid[i]));
    }
    /** Dtermines if the current player has no moves remaining. **/
    for(int i = 0; i < (this.a * this.b); i++){
      if(grid[i].getBackground().equals(saveBoard[i]) == false){
        result = true;
      }
    }
    /** Resets the game board. **/
    for(int i = 0; i < (this.a * this.b); i++){
      if(result){
        grid[i].setBackground(saveBoard[i]);
      }
    }
    return result;
  }
  
  /**
   * Checks if the game is over. If it is, calls tallyPoints to trigger the finishing procedure.
   **/
  public void gameOver(){
       if((Reversi.this.movesLeft() == false) && (p1)){
         p1 = false;
         if((Reversi.this.movesLeft() == false)){
           this.tallyPoints();
         }
       }
       else if((Reversi.this.movesLeft() == false) && (p1== false)){
         p1 = true;
         if((Reversi.this.movesLeft() == false)){
           this.tallyPoints();
         }
       }
  }
  
  /**
   * Lets the current player go again if the next player has no legal moves.
   **/
  public void hasLegalMove(){
        if((this.movesLeft() == false) && (p1)){
          p1 = false;
          System.out.println("Player 1, you have no legal moves. Player 2, it's your turn");
        }
        if((this.movesLeft() == false) && (p1 == false)){
          p1 = true;
          System.out.println("Player 2, you have no legal moves. Player 1, it's your turn");
        }
  }
  
  /**
   * Performs the "finishing procedure" (i.e. prints a message with the winner and the score; closes the game board).
   **/
  public void tallyPoints(){
    /** Remembers player1's total points. **/
    int p1 = 0;
    /** Remembers player2's total points. **/
    int p2 = 0;
    /** Counts the total points for each player. **/
    for(int i = 0; i < (this.a * this.b); i++){
      if(grid[i].getBackground().equals(p1Color))
        p1 = p1 + 1;
      if(grid[i].getBackground().equals(p2Color))
        p2 = p2 + 1;
    }
    if(p1 > p2){
      System.out.println("Player 1 wins! (" + p1 + "-" + p2 + ")");
      //this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }
    if(p2 > p1){
      System.out.println("Player 2 wins! (" + p2 + "-" + p1 + ")");
      //this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }
  }
  /**
   * The main method. Calls the appropriate constructor for the inputs given it. If inappropriate iputs are given,
   * prints out an error message explaining what is inappropriate about the iputs.
   * @NumberFormatException e
   **/
  public static void main(String[]args){
    if( (args.length > -1) && (args.length < 3)){
      /** Remembers the user's input, it's important to us. **/
      int[] args1 = new int[2];
      /** Determines if arguments are of the appropriate type. **/
      for(int i = 0; i < args.length; i++){
        try{
          args1[i] = Integer.parseInt(args[i]);
        }
        catch(NumberFormatException e) {
          System.err.println("Please use a numerical value in place of: " + args[i]);
          validD = false;
        }
      }
        if((args.length == 0) && (validD == true))
            new Reversi();
            System.out.println("Player 1, it's your turn");
        if((args.length == 1) && (validD == true)){
          if(args1[0] < 21){
           new Reversi(args1[0]);
           System.out.println("Player 1, it's your turn");
          }
          else{
            System.err.println("You can't even lift a board that big, bro.");
          }
        }
        if((args.length == 2) && (validD == true)){
          if((args1[0] < 21) && (args1[1] < 21)){
            new Reversi(args1[0], args1[1]);
            System.out.println("Player 1, it's your turn");
          }
          else{
            System.err.println("You can't even lift a board that big, bro.");
          }
        }
      }
    else{
      System.err.println("Please enter 0, 1, or 2 dimensions.");
    }
  }
  
  /** Below are the testing methods. **/
  public int getGridLength(){
    return this.grid.length;
  }
  
}
